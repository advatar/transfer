//
//  Observable-Swift.h
//  Observable-Swift
//
//  Created by Leszek Ślażyński on 20/06/14.
//  Copyright (c) 2014 Leszek Ślażyński. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Observable-Swift.
FOUNDATION_EXPORT double ObservableVersionNumber;

//! Project version string for Observable-Swift.
FOUNDATION_EXPORT const unsigned char ObservableVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Observable/PublicHeader.h>


